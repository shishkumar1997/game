from django.contrib.auth.models import Group
from django.conf import settings
from .models import Role
from django.contrib.auth import get_user_model
User = get_user_model()
from rest_framework import permissions



# class 