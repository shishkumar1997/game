from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': BASE_DIR / 'db.sqlite3',
#     }
# }

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'ayan_finserve_db',
        'ENGINE': 'mysql.connector.django',   # 'django.db.backends.mysql'
        'USER': 'secsales',
        'PASSWORD': 'sec&Gpi@123',
        'HOST': '49.50.69.231',
        'PORT': 3306,
        'OPTIONS': {
            'autocommit': True,
        },
    }
}