from django.db import models
from django.contrib.auth.models import  AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from .manager import *
# Create your models here.
class Role(models.Model):
    SuperAdmin = 1
    SubAdmin = 2
    BranchManager = 3
    
    ROLE_CHOICES = [
        (SuperAdmin, 'SuperAdmin'),
        (SubAdmin, 'SubAdmin'),
        (BranchManager, 'BranchManager'),
    ]
    role = models.CharField(max_length=25,default='SuperAdmin',null=False)
    class Meta:
        db_table = "user_roles"
    def __str__(self):
        return self.role

class NamePrefixMaster(models.Model):
    prefix=models.CharField(max_length=20)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'name_prefix_master'
        indexes = [
            models.Index(fields=['prefix','is_active']),
        ]

class CustomerTypeMaster(models.Model):
    customer_type=models.CharField(max_length=40)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'customer_type_master'
        indexes = [
            models.Index(fields=['customer_type','is_active']),
        ]

class OccupationMaster(models.Model):
    occupation=models.CharField(max_length=40)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'occupation_master'
        indexes = [
            models.Index(fields=['occupation','is_active']),
        ]

class CasteMaster(models.Model):
    caste=models.CharField(max_length=30)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'caste_master'
        indexes = [
            models.Index(fields=['caste','is_active']),
        ]

class RelationshipMaster(models.Model):
    relationship=models.CharField(max_length=30)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'relationship_master'
        indexes = [
            models.Index(fields=['relationship','is_active']),
        ]

class CountryMaster(models.Model):
    name=models.CharField(max_length=30)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'country_master'
        indexes = [
            models.Index(fields=['name','is_active']),
        ]

class StateMaster(models.Model):
    name=models.CharField(max_length=30)
    country=models.ForeignKey(CountryMaster,on_delete=models.CASCADE,null=True)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'state_master'
        indexes = [
            models.Index(fields=['name','is_active']),
        ]

class DistrictMaster(models.Model):
    name=models.CharField(max_length=30)
    state=models.ForeignKey(StateMaster,on_delete=models.CASCADE,null=True)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'district_master'
        indexes = [
            models.Index(fields=['name','is_active']),
        ]

class CityMaster(models.Model):
    name=models.CharField(max_length=30)
    district=models.ForeignKey(DistrictMaster,on_delete=models.CASCADE,null=True)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'city_master'
        indexes = [
            models.Index(fields=['name','is_active']),
        ]

class TalukaMaster(models.Model):
    name=models.CharField(max_length=30)
    city=models.ForeignKey(CityMaster,on_delete=models.CASCADE,null=True)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'taluka_master'
        indexes = [
            models.Index(fields=['name','is_active']),
        ]

class AreaMaster(models.Model):
    name=models.CharField(max_length=30)
    taluka=models.ForeignKey(TalukaMaster,on_delete=models.CASCADE,null=True)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = 'area_master'
        indexes = [
            models.Index(fields=['name','is_active']),
        ]

class Branch(models.Model):
    name=models.CharField(max_length=70)
    code=models.CharField(max_length=20,unique=True)
    address=models.CharField(max_length=100)
    city=models.ForeignKey(CityMaster,on_delete=models.CASCADE,null=True)
    is_active=models.BooleanField(default=True)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = "branch"
        indexes = [
            models.Index(fields=['name','code']),
        ]

class UserMaster(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=200,unique=True)
    email = models.EmailField(max_length=255,null=True, blank=True)
    phone_number = models.CharField(max_length=20, null=True, blank=True)
    first_name = models.CharField(max_length=200, null=True)
    middle_name = models.CharField(max_length=200, null=True, blank=True)
    last_name = models.CharField(max_length=200, null=True, blank=True)
    user_role = models.ForeignKey(Role, on_delete=models.CASCADE, null=True)
    branch = models.ForeignKey(Branch,on_delete=models.CASCADE,null=True)
    
     # module permission status =============
    master_management = models.BooleanField(default=True)
    customer_management = models.BooleanField(default=True)
    account_management = models.BooleanField(default=True)
    trnasaction_management = models.BooleanField(default=True)
    report_management = models.BooleanField(default=True)
    receipt_management = models.BooleanField(default=True)   
    
    
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    is_logged_in=models.BooleanField(default=False)
    profile_picture=models.FileField(upload_to='profile_picture/',null=True,blank=True)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    USERNAME_FIELD = 'username'
    objects = CustomUserManager()
    class Meta:
        db_table = 'user_master'
        indexes = [
            models.Index(fields=['email','username','phone_number','user_role']),
        ]
    def __str__(self):
        return self.username


class Customer(models.Model):
    customer_id=models.CharField(max_length=25,unique=True)
    branch=models.ForeignKey(Branch,on_delete=models.CASCADE,null=True)
    prefix=models.ForeignKey(NamePrefixMaster,on_delete=models.CASCADE,null=True)
    first_name=models.CharField(max_length=40)
    middle_name=models.CharField(max_length=40)
    last_name=models.CharField(max_length=40)
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('T', 'Transgender'),
        ('O', 'Other')
    ]
    gender = models.CharField(max_length=15,choices=GENDER_CHOICES, blank=True, null=True)
    date_of_birth=models.DateField(null=True)
    age=models.IntegerField()
    MARITAL_CHOICES = [
        ('single', 'Single'),
        ('married', 'Married'),
        ('divorced', 'Divorced'),
        ('widowed', 'Widowed'),
    ]
    marital_status = models.CharField(max_length=20, choices=MARITAL_CHOICES, blank=True, null=True)
    occupation=models.ForeignKey(OccupationMaster,on_delete=models.CASCADE)
    annual_income=models.CharField(max_length=15)
    caste=models.ForeignKey(CasteMaster,on_delete=models.CASCADE)
    residential_phone_number=models.CharField(max_length=15,null=True)

    mobile_numer=models.CharField(max_length=10)
    phone_otp=models.CharField(max_length=8,null=True)

    otp_expiry=models.DateTimeField(null=True)
    is_otp_verified=models.BooleanField(default=False)

    email_id=models.EmailField(max_length=100,null=True)
    aadhar_number=models.CharField(max_length=12)
    
            
    # default ===============================
    created_on=models.DateTimeField(auto_now_add=True)
    created_by=models.ForeignKey(UserMaster,on_delete=models.CASCADE,related_name='created_by')
    updated_on=models.DateTimeField(blank=True,null=True)
    updated_by=models.ForeignKey(UserMaster,on_delete=models.CASCADE,related_name='updated_by',blank=True, null=True)
    is_active=models.BooleanField(default=True)
    comment = models.CharField(max_length=300,null=True, blank=True)
    is_deleted=models.BooleanField(default=False)
    class Meta:
        db_table = "customer_details"
        indexes = [
            models.Index(fields=['customer_id']),
        ]

class CustomerOTPVerification(models.Model):
    mobile_numer=models.CharField(max_length=10,unique=True)
    phone_otp=models.CharField(max_length=8,null=True)
    otp_expiry=models.DateTimeField(null=True)
    is_otp_verified=models.BooleanField(default=False)
    created_on=models.DateTimeField(auto_now=True)
    class Meta:
        db_table = "customer_otp_details"
        indexes = [
            models.Index(fields=['mobile_numer']),
        ]




class CustomerAddressDetails(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    country=models.ForeignKey(CountryMaster,on_delete=models.CASCADE,blank=True,null=True)
    state=models.ForeignKey(StateMaster,on_delete=models.CASCADE,blank=True,null=True)
    district=models.ForeignKey(DistrictMaster,on_delete=models.CASCADE,blank=True,null=True)
    city=models.ForeignKey(CityMaster,on_delete=models.CASCADE,blank=True,null=True)
    taluka=models.ForeignKey(TalukaMaster,on_delete=models.CASCADE,blank=True,null=True)
    area=models.ForeignKey(AreaMaster,on_delete=models.CASCADE,blank=True,null=True)
    
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    is_deleted=models.BooleanField(default=False)
    class Meta:
        db_table = "customer_address_details"
        indexes = [
            models.Index(fields=['customer']),
        ]

class CustomerNomineeDetails(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    nominee_name=models.CharField(max_length=100)
    nominee_dob=models.DateField(blank=True,null=True)
    relation_with_customer=models.ForeignKey(RelationshipMaster,on_delete=models.CASCADE)
    nominee_number = models.CharField(max_length=35, blank=True,null=True)
    nominee_document = models.FileField(upload_to = 'nominee_doc/',blank=True,null=True)
    
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    is_deleted=models.BooleanField(default=False)
    class Meta:
        db_table = "customer_nominee_details"
        indexes = [
            models.Index(fields=['customer']),
        ]

class CustomerDocumentDetails(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    document_id=models.CharField(max_length=10,blank=True,null=True)
    document_name=models.CharField(max_length=20)
    document_number=models.CharField(max_length=30)
    
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    is_deleted=models.BooleanField(default=False)
    class Meta:
        db_table = "customer_document_details"
        indexes = [
            models.Index(fields=['customer']),
        ]

class CustomerPhotoSignatureDetails(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    customer_photo=models.FileField(upload_to = 'customer_photo/')
    customer_signature=models.FileField(upload_to = 'customer_signature/')
    
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    is_deleted=models.BooleanField(default=False)
    class Meta:
        db_table = "customer_photo_signature_details"
        indexes = [
            models.Index(fields=['customer']),
        ]

class CustomerBankAccountDetails(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    bank_account_number=models.CharField(max_length=20)
    account_holder_name=models.CharField(max_length=100)
    nick_name=models.CharField(max_length=50,null=True,blank=True)
    bank_name=models.CharField(max_length=40)
    bank_branch_name=models.CharField(max_length=50)
    bank_ifsc=models.CharField(max_length=20)
    bank_icmr=models.CharField(max_length=20)
    status=models.BooleanField(default=True)
    
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    is_deleted=models.BooleanField(default=False)
    class Meta:
        db_table = "customer_bank_account_details"
        indexes = [
            models.Index(fields=['customer']),
        ]

# class SchemeClassificationMaster(models.Model):
#     scheme_classification=models.CharField(max_length=15,unique=True)
#     is_active=models.BooleanField(default=True)
#     is_deleted=models.BooleanField(default=True)
#     created_on=models.DateTimeField(auto_now_add=True)
#     updated_on=models.DateTimeField(blank=True,null=True)
#     class Meta:
#         db_table = "scheme_classification_master"
#         indexes = [
#             models.Index(fields=['scheme_classification']),
#         ]


class SchemeMaster(models.Model):
    # classification=models.ForeignKey(SchemeClassificationMaster,on_delete=models.CASCADE)
    scheme_name=models.CharField(max_length=30)
    is_active=models.BooleanField(default=True)
    is_deleted=models.BooleanField(default=True)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(blank=True,null=True)
    class Meta:
        db_table = "scheme_master"
        indexes = [
            models.Index(fields=['scheme_name']),
        ]

# ### Customer Loan Account******************
class LoanAccount(models.Model):
    loan_account_number=models.CharField(max_length=25,unique=True)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    nominee = models.ForeignKey(CustomerNomineeDetails, on_delete=models.CASCADE, blank=True, null=True)
    scheme = models.ForeignKey(SchemeMaster,on_delete=models.CASCADE, blank=True, null=True)
    opening_date = models.DateTimeField(auto_now_add=True)
    classification=models.CharField(max_length=150,null=True,blank=True)
    period_unit=models.CharField(max_length=25)
    loan_period=models.IntegerField()
    tenure_date=models.DateField(null=True,blank=True)
    operating_instructions=models.CharField(max_length=100,null=True,blank=True)
    purpose=models.CharField(max_length=100,null=True,blank=True)

    is_active=models.BooleanField(default=True)
    is_deleted=models.BooleanField(default=True)
    created_on=models.DateTimeField(auto_now_add=True)
    updated_on=models.DateTimeField(auto_now=True)
    created_by=models.ForeignKey(UserMaster,on_delete=models.CASCADE,related_name='created_by_user',null=True,blank=True)
    updated_by=models.ForeignKey(UserMaster,on_delete=models.CASCADE,related_name='updated_by_user',null=True,blank=True)

    class Meta:
        db_table = "loan_account"
        indexes = [
            models.Index(fields=['customer']),
        ]
