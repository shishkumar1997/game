import datetime
from django.shortcuts import render
from rest_framework import status,generics,permissions
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from django.db.models import Q
from dateutil.relativedelta import relativedelta
from rest_framework.parsers import FormParser, MultiPartParser, FileUploadParser
import time
from django.utils import timezone
from .serializers import *
from api.v1.models import *
from ayaan_finserve.paginations import *
from django.core.cache import cache
from django.conf import settings
from django.core.cache.backends.base import DEFAULT_TIMEOUT
from rest_framework.permissions import IsAuthenticated
# For cache timeout
CACHE_TTL = getattr(settings, 'CACHE_TTL', DEFAULT_TIMEOUT)
from django.http import FileResponse
from .utils import *
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
class GetSchemeName(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=GetSchemeNameSerializer
    filter_backends=[filters.SearchFilter]
    search_fields=['scheme_name']
    def get_queryset(self):
        try:
            valid_scheme=SchemeMaster.objects.filter(is_active=True,is_deleted=False).all()
            return valid_scheme
        except Exception as e:
            return SchemeMaster.objects.none()



class GetCustomerID(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=GetCustomerIDSerializer
    filter_backends=[django_filters.rest_framework.DjangoFilterBackend,filters.SearchFilter]
    search_fields=['customer_id']
    def get_queryset(self):
        try:
            customer_id_list=Customer.objects.filter(is_active=True,is_deleted=False).all()
            return customer_id_list
        except Exception as e:
            return Customer.objects.none()
class GetCustomerDetails(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=GetCustomerIDSerializer
    def get(self,request,customer_id,*args,**kwargs):
        try:
            customer_instance=Customer.objects.get(customer_id=customer_id)
            serialized_data=self.serializer_class(customer_instance)
            context={'status':True,'message':'details fetched successfully','data':serialized_data.data}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class GetLoanTenureDate(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    period_unit_config = openapi.Parameter('period_unit',in_=openapi.IN_QUERY, type=openapi.TYPE_STRING)
    loan_period_config = openapi.Parameter('loan_period',in_=openapi.IN_QUERY, type=openapi.TYPE_STRING)

    @swagger_auto_schema(manual_parameters=[period_unit_config,loan_period_config])
    def get(self,request,*args,**kwargs):
        try:
            period_unit=self.request.query_params.get('period_unit')
            loan_period=self.request.query_params.get('loan_period')
            try:
                loan_tenure=LoanTenureDateCalculation(period_unit=period_unit,loan_period=loan_period)
                tenure_date=loan_tenure.calculate_tenure_date()
                context={'status':True,'message':'details fetched successfully','tenure_date':tenure_date}
                return Response(context,status=status.HTTP_200_OK)
            except ValueError as e:
                context={'status':False,'message':str(e)}
                return Response(context,status=status.HTTP_406_NOT_ACCEPTABLE)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AddCustomerLoanAccount(generics.GenericAPIView):
    permission_classes=(IsAuthenticated,)
    serializer_class=CustomerLoanAccountCreationSerializer
    def post(self,request,*args,**kwargs):
        try:
            customer_instance=LoanAccount.objects.filter(customer_id=int(request.data['customer_id'])).last()
            if customer_instance:
                context={'status':False,'message':'Account already exists'}
                return Response(context,status=status.HTTP_400_BAD_REQUEST)
            else:
                serialized_data=self.serializer_class(data=request.data,context={'request':request})
                if serialized_data.is_valid():
                    context={'status':True,'message':'Loan Account Created Successfully'}
                    return Response(context,status=status.HTTP_201_CREATED)
                else:
                    context={'status':False,'message':serialized_data.errors}
                    return Response(context,status=status.HTTP_406_NOT_ACCEPTABLE)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)