from django.utils import timezone
from rest_framework import serializers
from ..models import *
from django.db import IntegrityError, transaction
from django.conf import settings
from .utils import *
class GetSchemeNameSerializer(serializers.ModelSerializer):
    current_date=serializers.SerializerMethodField()
    class Meta:
        model=SchemeMaster
        fields=['scheme_name','current_date']
    def get_current_date(self,obj):
        return timezone.now().date()

class NomineeDetailsSerializer(serializers.ModelSerializer):
    customer_id=serializers.SerializerMethodField()
    relationship=serializers.SerializerMethodField()
    class Meta:
        model=CustomerNomineeDetails
        fields=['id','customer_id','nominee_name','nominee_dob','relationship']
    def get_customer_id(self,obj):
        return obj.customer.customer_id
    def get_relationship(self,obj):
        return obj.relation_with_customer.relationship

class GetCustomerIDSerializer(serializers.ModelSerializer):
    customer_name=serializers.SerializerMethodField()
    nominee_details=serializers.SerializerMethodField()
    class Meta:
        model=Customer
        fields=['id','customer_id','customer_name','nominee_details']

    def get_customer_name(self,obj):
        return (f"{obj.first_name}{' '+obj.middle_name if obj.middle_name else ''}{' '+obj.last_name if obj.last_name else ''}").strip()
    def get_nominee_details(self,obj):
        nominee_instance=CustomerNomineeDetails.objects.get(customer_id=obj.id)
        return NomineeDetailsSerializer(nominee_instance).data


class CustomerLoanAccountCreationSerializer(serializers.ModelSerializer):
    scheme_id=serializers.IntegerField(required=True)
    classification =serializers.CharField(max_length=150,required=True)
    tenure_date=serializers.DateField(required=True)
    customer_id=serializers.IntegerField(required=True)
    operating_instructions=serializers.CharField(max_length=100,required=True)
    purpose=serializers.CharField(max_length=100,required=True)
    
    class Meta:
        model=LoanAccount
        fields=['customer_id','scheme_id','opening_date','classification','period_unit','loan_period','tenure_date','operating_instructions','purpose']
    
    def validate(self,attrs):
        try:
            with transaction.atomic():
                request=self.context.get('request')
                loan_account_instance=LoanAccount()
                loan_account_instance.customer_id=attrs['customer_id']
                loan_account_instance.nominee_id=CustomerNomineeDetails.objects.get(customer_id=attrs['customer_id']).id
                loan_account_instance.scheme_id=attrs['scheme_id']
                loan_account_instance.classification=attrs['classification']
                loan_account_instance.period_unit=attrs['period_unit']
                loan_account_instance.loan_period=attrs['loan_period']
                loan_account_instance.tenure_date=attrs['tenure_date']
                loan_account_instance.operating_instructions=attrs['operating_instructions']
                loan_account_instance.purpose=attrs['purpose']
                loan_account_instance.created_by=request.user
                branch_code=request.user.branch.code
                scheme_code=(SchemeMaster.objects.get(id=attrs['scheme_id']).scheme_name).split(' ')[0]
                loan_account_number_obj = GenerateLoanAccountNumber(branch_code=branch_code,scheme_code=scheme_code)
                loan_account_instance.loan_account_number=loan_account_number_obj.get_loan_account_number()
                loan_account_instance.save()
                return attrs
        except Exception as e:
            raise serializers.ValidationError({'error':str(e)})