import datetime
from django.utils import timezone
from dateutil.relativedelta import relativedelta
from ..models import *
class LoanTenureDateCalculation:
    def __init__(self,period_unit = None,loan_period= None) -> None:
        self.period_unit = period_unit
        self.loan_period = loan_period
    
    def validate_period_unit(self,period_unit):
        valid_period_units=['year','month','week','day']
        return True if period_unit in valid_period_units else False
    
    def calculate_tenure_date(self):
        result=self.validate_period_unit(self.period_unit)
        if result:
            if self.period_unit=='year':
                return (timezone.now()+relativedelta(years=int(self.loan_period))).date()
            elif self.period_unit == 'month':
                return (timezone.now()+relativedelta(months=int(self.loan_period))).date()
            elif self.period_unit == 'days':
                return (timezone.now()+relativedelta(days=int(self.loan_period))).date()
            elif self.period_unit == 'week':
                return (timezone.now()+relativedelta(weeks=int(self.loan_period))).date()
        else:
            raise ValueError('invalid period unit')


class GenerateLoanAccountNumber:
    def __init__(self,branch_code=None,scheme_code=None) -> None:
        self.branch_code = branch_code
        self.scheme_code = scheme_code

    def get_loan_account_number(self):
        latest_account_number=LoanAccount.objects.last().loan_account_number if LoanAccount.objects.last() else None
        if latest_account_number is None:
            unique_code=f"{self.branch_code}{self.scheme_code}"+'0000'+'1'
            return unique_code
        else:
            last_number=latest_account_number.split('0000')[1]
            unique_code=f"{self.branch_code}{self.scheme_code}"+'0000'+ f"{int(last_number)+1}"
            return unique_code

