from api.v1.customer.management.views import *
from django.urls import path
from api.v1.customer.views import *

urlpatterns = [
    path('customer_list/',CustomerListApiView.as_view(),name="customer_list"),
    path('get_photo_signature/',PhotoSignatureView.as_view(),name='get_photo_signature'),
    path('upload_photo_signature/',PhotoSignatureUpload.as_view(),name="upload_photo_signature"),
    path('customer_registration/',CustomerRegistration.as_view(),name="customer_registration"),

    path('edit_photo_signature/<str:customer_id>',PhotoSignatureEdit.as_view(),name="edit_photo_signature"),
    path('upload_photo_signature/',PhotoSignatureUpload.as_view(),name="upload_photo_signature"),

    path('customer_status_update/<str:customer_id>',CustomerStatusUpdate.as_view(),name='customer_status_update'),
    path('customer_bank_account_details/',GetCustomerBankAccountDetails.as_view(),name='customer_bank_account_details'),
    
    path('document_list/',DocumentListApiView.as_view(),name="document_list"),
    path('add_document/',AddDocument.as_view(),name='add_document'),
    path('update_delete_document/<str:id>',UpdateDeleteDocument.as_view(),name='update_delete_document'),



]