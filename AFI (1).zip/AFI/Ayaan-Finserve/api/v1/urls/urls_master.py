from django.urls import path
from api.v1.masters.views import *

urlpatterns = [
    path('get_name_prefix/',NamePrefixList.as_view(),name='get_name_prefix'),
    path('update_delete_prefix/<str:prefix_id>',UpdateNamePrefixStatus.as_view(),name='update_prefix_status'),
    path('add_name_prefix/',AddNamePrefix.as_view(),name='add_name_prefix'),

    path('get_customer_type/',CustomerTypeList.as_view(),name='get_customer_type'),
    path('update_customer_type_status/<str:customer_type_id>',UpdateCustomerTypeStatus.as_view(),name='update_customer_type_status'),
    path('add_customer_type/',AddCustomerType.as_view(),name='add_customer_type'),

    path('get_occupation/',OccupationList.as_view(),name='get_occupation'),
    path('update_occupation_status/<str:occupation_id>',UpdateOccupationStatus.as_view(),name='update_occupation_status'),
    path('add_occupation/',AddOccupation.as_view(),name='add_occupation'),

    path('get_caste/',CasteList.as_view(),name='get_caste'),
    path('update_caste_status/<str:caste_id>',UpdateCateStatus.as_view(),name='update_caste_status'),
    path('add_caste/',AddCaste.as_view(),name='add_caste'),

    path('get_relationship/',RelationshipList.as_view(),name='get_relationship'),
    path('update_relationship_status/<str:relationship_id>',UpdateRelationshipStatus.as_view(),name='update_relationship_status'),
    path('add_relationship/',AddRelationship.as_view(),name='add_relationship'),

    path('get_country/',CountryList.as_view(),name='get_country'),
    path('update_country_status/<str:country_id>',UpdateCountryStatus.as_view(),name='update_country_status'),
    path('add_country/',AddCountry.as_view(),name='add_country'),

    path('get_state/',StateList.as_view(),name='get_state'),
    path('update_state_status/<str:state_id>',UpdateStateStatus.as_view(),name='update_state_status'),
    path('add_state/',AddState.as_view(),name='add_state'),

    path('get_district/',DistrictList.as_view(),name='get_district'),
    path('update_district_status/<str:district_id>',UpdateDistrictStatus.as_view(),name='update_district_status'),
    path('add_district/',AddDistrict.as_view(),name='add_district'),

    path('get_taluka/',TalukaList.as_view(),name='get_taluka'),
    path('update_taluka_status/<str:taluka_id>',UpdateTalukaStatus.as_view(),name='update_taluka_status'),
    path('add_taluka/',AddTaluka.as_view(),name='add_taluka'),

    path('get_city/',CityList.as_view(),name='get_city'),
    path('update_city_status/<str:city_id>',UpdateCityStatus.as_view(),name='update_city_status'),
    path('add_city/',AddCity.as_view(),name='add_city'),

    path('get_area/',AreaList.as_view(),name='get_area'),
    path('update_area_status/<str:area_id>',UpdateAreaStatus.as_view(),name='update_area_status'),
    path('add_area/',AddArea.as_view(),name='add_area'),
]