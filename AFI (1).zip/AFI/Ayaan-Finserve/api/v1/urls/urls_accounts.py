from django.urls import path
from api.v1.account.views import ChangePassword, UserLoginGenerics,UserRefreshTokenGeneratorGenerics,DashboardView,AccountProfile

urlpatterns = [ 
    path('urls_account/account/login/', UserLoginGenerics.as_view(),name='account_login'),
    path('token/refresh_roken/', UserRefreshTokenGeneratorGenerics.as_view(), name='token_refresh'),
    path('dashboard/',DashboardView.as_view(),name='dashboard'),
    path('change_password/',ChangePassword.as_view(),name='change_password'),
    path('account/profile/',AccountProfile.as_view(),name ='account_profile'),

]