from django.urls import path
# from api.v1.account.views import UserLoginGenerics

urlpatterns = [ 
    # path('urls_account/account/login/', UserLoginGenerics.as_view(),name='account_login'),
]