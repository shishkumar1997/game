from django.urls import path
from api.v1.customer_loan.views import *
urlpatterns = [
    path('get_scheme_name/',GetSchemeName.as_view(),name='get_scheme_name'),
    path('get_customer_id/',GetCustomerID.as_view(),name='get_customer_id'),
    path('get_customer_details/<str:customer_id>',GetCustomerDetails.as_view(),name='get_customer_details'),
    path('get_loan_tenure_date/',GetLoanTenureDate.as_view(),name='get_loan_tenure_date'),
    path('add_customer_loan_account/',AddCustomerLoanAccount.as_view(),name='add_customer_loan_account'),



]
