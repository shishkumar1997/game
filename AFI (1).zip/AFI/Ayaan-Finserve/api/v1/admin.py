from django.contrib import admin
from .models import Role, UserMaster,Branch
# Register your models here.
admin.site.register(UserMaster)
admin.site.register(Role)
admin.site.register(Branch)