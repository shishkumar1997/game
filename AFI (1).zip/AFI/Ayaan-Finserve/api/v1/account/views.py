
import datetime
from api.v1.models import UserMaster
from api.v1.account.serializers import UserLoginGenericsSerializer,SingleUserDetailsSerializer,UserRefreshTokenSerializer,ProfileSerializer,ChangePasswordSerializer
from rest_framework import generics, status, permissions
from rest_framework.response import Response
from django.db.models import Q

# User Login Here.
class UserLoginGenerics(generics.GenericAPIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = UserLoginGenericsSerializer
    def post(self, request, *args, **kwargs):
        try:
            user = UserMaster.objects.filter(Q(email=request.data.get('email'))|Q(username = request.data.get('email')), is_deleted=False).last()
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                serialized_user = SingleUserDetailsSerializer(user).data
                context = {'status': True,'message': 'Login Successfully','data': serialized_user}
                return Response(context, status=status.HTTP_200_OK)
            context = {'data':{'status': False,'message': serializer.errors['error'],'logged_in':False}}
            return Response(context, status=status.HTTP_200_OK)
            
        except Exception as e:
            context = {'status': False, 'message': str(e)}
            return Response(context, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# User Refresh Token Generate.
class UserRefreshTokenGeneratorGenerics(generics.GenericAPIView):
    serializer_class = UserRefreshTokenSerializer
    def post(self, request, *args, **kwargs):
        try:
            
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid():
                context = {'status': True,'message': 'Token find successfully','data':serializer.data}
                return Response(context, status=status.HTTP_200_OK)
            context = {'status': False,'message': serializer.errors['error']}
            return Response(context, status=status.HTTP_200_OK)
        except Exception as e:
            context = {'status': False, 'message': str(e)}
            return Response(context, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    def post(self, request):
        context = {"message" : "Successfull.", "status" : True}
        return Response(context,status=status.HTTP_200_OK)

# Dashboard
class DashboardView(generics.GenericAPIView):
    def get(self,request,*args,**kwargs):
        try:
            data = {}
            data['loans_disbursed']=0
            data['total_deposits']=0
            data['total_interest_received']=0
            data['total_insterest_paid']=0
            data['cash_at_branch']=0
            data['net_profit']=0
            data['loan_diagnostics']=0
            data['loan_due']=0
            context={'status':True,'message':'data fetched successfully','data':data}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something Went Wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Account Profile
class AccountProfile(generics.GenericAPIView):
    permission_classes = (permissions.IsAuthenticated,)
    serializer_class = ProfileSerializer
    def get(self,request):
        try :
            user = UserMaster.objects.filter(id=self.request.user.id).last()
            serializer = self.serializer_class(user,many=False)
            context = {'status': True,'message': 'Data found successfully','data':serializer.data}
            return Response(context, status=status.HTTP_200_OK)
                
        except Exception as e:
            context = {'status': False, 'message': str(e)}
            return Response(context, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# Change Password
class ChangePassword(generics.GenericAPIView):
    permission_classes = (permissions.IsAuthenticated,)
    serializer_class = ChangePasswordSerializer
    def patch(self,request):
        try:
            serializer = self.serializer_class(data=request.data,context={"userid":self.request.user.id})
            if serializer.is_valid():
                                                    
                context = {'status': True,'message': 'Password has been updated successfully.'}
                return Response(context, status=status.HTTP_200_OK)
            
            context = {'status': False,'message': serializer.errors['error'][0]}
            return Response(context, status=status.HTTP_200_OK)
        except Exception as e:
            context = {'status': False, 'message': str(e)}
            return Response(context, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
