from api.v1.account.utils import generate_access_token, generate_refresh_token
from api.v1.models import Role, UserMaster
from rest_framework import serializers
from django.db.models import Q
import jwt
from django.conf import settings
from django.contrib.auth.hashers import make_password,check_password



# User Login Serializers.
class UserLoginGenericsSerializer(serializers.ModelSerializer):
    email = serializers.CharField(max_length=600,error_messages={'blank': 'Please enter email address'})
    password = serializers.CharField(max_length=600,error_messages={'blank': 'Please enter password'})
    class Meta:
        ref_name = 'UserGenericLogin'
        model = UserMaster
        fields = ('email','password')

    def validate(self, attrs):
        email = attrs.get('email')
        password = attrs.get('password')
        user = UserMaster.objects.filter(Q(email=email)|Q(username = email),is_deleted=False).last()
        if user is None:
            raise serializers.ValidationError({'error' : 'Invalid Credential.'})
        if (not user.check_password(password)):  
            raise serializers.ValidationError({'error' : 'Invalid Credential.'})
        if user.is_active == False:
            raise serializers.ValidationError({'error' : 'Your account is inactive.Please contact support team.'})
        return super().validate(attrs)


# Single User Details Serializers
class SingleUserDetailsSerializer(serializers.ModelSerializer):
    access_token = serializers.SerializerMethodField()
    refresh_token = serializers.SerializerMethodField()
    role = serializers.SerializerMethodField()
    class Meta:
        ref_name = 'SingleUserDetails'
        model = UserMaster
        fields = ('id','email','username','first_name','last_name','middle_name','user_role','role','is_logged_in','master_management','customer_management','account_management','trnasaction_management','report_management','receipt_management','access_token','refresh_token')
    def get_access_token(self, obj):
        return generate_access_token(obj.id)
    def get_refresh_token(self, obj):
        refresh_token = generate_refresh_token(obj.id)
        return refresh_token
    def get_role(self, obj):
        return obj.user_role.role
        
# Account Profile Serializers.
class ProfileSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    class Meta:
        ref_name = 'SingleUserDetails'
        model = UserMaster
        fields = ('id','email','username','first_name','last_name','middle_name','user_role','role','phone_number','profile_picture','branch','master_management','customer_management','account_management','trnasaction_management','report_management','receipt_management')

    def get_role(self, obj):
        return obj.user_role.role


# User Refresh Token Serializers.
class UserRefreshTokenSerializer(serializers.Serializer):
    refresh_token = serializers.CharField(max_length=255,error_messages={'blank': 'Please enter refresh_token'})
    access_token = serializers.CharField(read_only=True)

    ref_name ='UserRefreshToken'

    def validate(self, attrs):
        refresh_token = attrs.get('refresh_token')
        try:
            payload = jwt.decode(refresh_token, settings.SECRET_KEY, algorithms=["HS256"])
        except jwt.ExpiredSignatureError as e:
            raise serializers.ValidationError({'error': 'Expired refresh token, please login again.'}) from e
        print(payload,'8888888')
        user = UserMaster.objects.filter(id=payload.get('user_id')).first()
        if user is None:
            raise serializers.ValidationError({'error' : 'User not found'})
        if not user.is_active:
            raise serializers.ValidationError({'error' : 'User is inactive'})
        access_token = generate_access_token(user.id)
        attrs['access_token'] = str(access_token).strip("b'")

# change password  Serializer
class ChangePasswordSerializer(serializers.Serializer):
        
        old_password = serializers.CharField(max_length = 30)
        new_password = serializers.CharField(max_length = 30)
        confirm_new_password = serializers.CharField(max_length = 30)
        
        
        def validate(self, attrs):
            
            if attrs.get('new_password') != attrs.get('confirm_new_password'):
                raise serializers.ValidationError({"error":"Passwords don't match."})
            print(self.context.get('userid'))
            user = UserMaster.objects.get(id=self.context.get('userid'))
            print(user,'hhhhhhhhhh')
            check_pass = check_password(attrs.get('new_password'),user.password)
            if check_pass == True:
                raise serializers.ValidationError({"error":"you cannot use current password"})
            print(check_pass,'ddddd')
            user = UserMaster.objects.filter(id=self.context.get('userid')).update(password = make_password(attrs.get('confirm_new_password')))
            

            return super().validate(attrs)