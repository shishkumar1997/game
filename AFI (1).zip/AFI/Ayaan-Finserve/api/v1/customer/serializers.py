import datetime
import logging
from .utills import SystemGenerate
from rest_framework import serializers
from ..models import *
from django.db import IntegrityError, transaction
from django.contrib.auth.hashers import make_password
import re
from django.conf import settings


logger = logging.getLogger('mylogger')

class PhotoSignatureSerializer(serializers.ModelSerializer):
    customer_id=serializers.SerializerMethodField()
    photo=serializers.SerializerMethodField()
    signature=serializers.SerializerMethodField()
    date=serializers.SerializerMethodField()
    class Meta:
        model=CustomerPhotoSignatureDetails
        fields=['customer_id','photo','signature','date']
    def get_customer_id(self,obj):
        return obj.customer.customer_id
    def get_photo(self,obj):
        request=self.context.get('request')
        try:
            base_url=str(request.build_absolute_uri('/'))
            return f"{base_url[:-1]}{obj.customer_photo.url}"
        except Exception as e:
            return None
    def get_signature(self,obj):
        request=self.context.get('request')
        try:
            base_url=request.build_absolute_uri('/')
            return f"{base_url}{obj.customer_signature.url}"
        except Exception as e:
            return None
    def get_date(self,obj):
        return obj.created_on


class PhotoSignatureUploadSerializer(serializers.ModelSerializer):
    customer_id=serializers.CharField(max_length=50,required=True)
    customer_photo=serializers.FileField(required=True)
    customer_signature=serializers.FileField(required=True)
    class Meta:
        model=CustomerPhotoSignatureDetails
        fields=['customer_id','customer_photo','customer_signature']
    def validate(self,attrs):
        customer_instance=CustomerPhotoSignatureDetails.objects.filter(customer_id=attrs['customer_id']).last()
        customer_instance.customer_photo=attrs['photo']
        customer_instance.customer_signature=attrs['signature']
        customer_instance.save()
        return attrs

class PhotoSignatureEditSerializer(serializers.ModelSerializer):
    class Meta:
        model=CustomerPhotoSignatureDetails
        fields=['customer_photo','customer_signature']



class CustomerAddressSaveUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerAddressDetails
        fields = '__all__'
        
class CustomerNomineeSaveUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerNomineeDetails
        fields = '__all__'

class CustomerAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerAddressDetails
        fields = ['country','state','district']
        ref_name="address"
        


class CustomerNomineeSerializer(serializers.ModelSerializer):
    # country = serializers.CharField()
    # name = serializers.CharField()
    # releation = serializers.IntegerField()
    class Meta:
        model = CustomerNomineeDetails
        fields = ['nominee_name','relation_with_customer']


class CustomerRegistrationSerializer(serializers.ModelSerializer):
    # branch = serializers.IntegerField()
    # customer_address = CustomerAddressSerializer(many = True)
    gender = serializers.CharField(default="[('M', 'Male'),('F', 'Female'),('O', 'Other')]")
    nominee_name = CustomerNomineeSerializer(many=True)
    customer_address=CustomerAddressSerializer(many=True)
    
    class Meta :
        model=Customer
        # fields = ['branch',]
        ref_name = 'PostServeyQuestion'
        fields = ['branch','prefix','first_name','middle_name','last_name','gender','date_of_birth','occupation','caste','age','nominee_name','customer_address']
    def validate(self, attrs):
        print(attrs['nominee_name'],"===========",attrs['customer_address'])
        obj = SystemGenerate(branch = attrs['branch'],customer_name = attrs['first_name'])
        print(obj.generate_customer_id(),"==========code")
        # breakpoint()
        custome_obj = Customer()
        custome_obj.customer_id = obj.generate_customer_id()
        custome_obj.branch = attrs['branch']
        custome_obj.prefix = attrs['prefix']
        custome_obj.first_name = attrs['first_name']
        custome_obj.middle_name = attrs['middle_name']
        custome_obj.last_name = attrs['last_name']
        custome_obj.gender = attrs['gender']
        custome_obj.occupation = attrs['occupation']
        custome_obj.caste = attrs['caste']
        custome_obj.created_by_id = 2
        custome_obj.date_of_birth = attrs['date_of_birth']
        custome_obj.age = attrs['age']
        custome_obj.save()   
        # return super().validate(attrs)
        address_data = attrs['customer_address']
        # print(address_data,"=========",attrs)
        for data in address_data:
            data = dict(data)
            print(data['country'].id,'=====add')
            CustomerAddressDetails.objects.create(customer_id=custome_obj.id ,country_id=data['country'].id,state_id=data['state'].id,district_id=data['district'].id)        
        #     # customer_address=CustomerAddress()
            
        nominee = attrs['nominee_name']
        for data in nominee:
            data = dict(data)
            
            print(data,'=====nom')
            CustomerNomineeDetails.objects.create(customer_id=custome_obj.id,nominee_name=data['nominee_name'],relation_with_customer=data['relation_with_customer'])   
            
        return data
                
            
        # nominee_data = [i['customer'] = custome_obj for i in attrs['nominee_name']]
        # customer_address = [i['customer'] = custome_obj for i in attrs['nominee_name']]

#Serializers for Customer Status
class GetCustomerStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model=Customer
        fields=['id','customer_id','is_active']

class CustomerStatusUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    comment=serializers.CharField(max_length=300,required=True)
    class Meta:
        model=Customer
        fields=['is_active',"comment"]


#Serializers for Customer Bank Account
class CustomerBankAccountDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model=CustomerBankAccountDetails
        fields='__all__'
