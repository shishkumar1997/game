from api.v1.models import Customer, CustomerDocumentDetails

class SystemGenerate:
    def __init__(self,branch = None,customer_name= None, document_name= None ) -> None:
        self.branch = branch
        self.customer_name = customer_name
        self.document_name = document_name

        
    def generate_customer_id(self):
        last_id_customer = Customer.objects.last()
        last_id_customer = (last_id_customer.id)+1 if last_id_customer else 1
        return f"{self.branch[0]}{self.customer_name[0]}{self.customer_name[1]}{last_id_customer:05}"

    def generate_document_id(self):
        last_id_document = CustomerDocumentDetails.objects.last()
        last_id_document = (last_id_document.id)+1 if last_id_document else 1
        return f"{self.document_name[0]}{self.document_name[1]}{last_id_document:02}"