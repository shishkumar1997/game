from api.v1.customer.utills import SystemGenerate
from api.v1.models import *
from rest_framework import serializers

# customer document listing search serializer
class DocumentListSerializer(serializers.ModelSerializer):
    customer_customer_id = serializers.SerializerMethodField()

    class Meta:
        ref_name = 'DocumentListSerializer'
        model = CustomerDocumentDetails
        fields = ['id','customer','customer_customer_id','document_id','document_name','document_number','created_on']
        
    def get_customer_customer_id(self, obj):
        if obj.customer:
            return obj.customer.customer_id
        return None


# customer document add
class AddDocumentSerialzier(serializers.ModelSerializer):
    class Meta:
        ref_name = 'AddDocumentSerialzier'
        model=CustomerDocumentDetails
        fields=['customer','document_name','document_number']
    def validate(self, attrs):
        obj = SystemGenerate(document_name = attrs['document_name'])
        document_obj = CustomerDocumentDetails()
        document_obj.customer = attrs['customer']
        document_obj.document_id = obj.generate_document_id()
        document_obj.document_name = attrs['document_name']
        document_obj.document_number = attrs['document_number']
        document_obj.save() 
        return super().validate(attrs)

class DocumentUpdateSerializer(serializers.ModelSerializer):
    document_number=serializers.CharField(max_length=30,required=True)
    document_name=serializers.CharField(max_length=20,required=True)
    class Meta:
        model=CustomerDocumentDetails
        fields=['document_number','document_name']

# customer listing search serializer
class CustomerListSerializer(serializers.ModelSerializer):
    branch_code = serializers.SerializerMethodField()
    customer_name = serializers.SerializerMethodField()

    class Meta:
        ref_name = 'CustomerListSerializer'
        model = Customer
        fields = ['id','customer_id','customer_name','mobile_numer','aadhar_number','branch','branch_code']
        
    def get_branch_code(self, obj):
        if obj.branch:
            return obj.branch.code
        return None
    
    def get_customer_name(self, obj):
            if obj.customer_name:
                customer_name = f"{obj.customer_name.first_name} {obj.customer_name.last_name}"
                return customer_name
            else:
                return None