from api.v1.customer.management.serializers import AddDocumentSerialzier, CustomerListSerializer, DocumentListSerializer, DocumentUpdateSerializer
from api.v1.models import Customer, CustomerDocumentDetails
from ayaan_finserve.paginations import CustomPaginationClass
import django_filters.rest_framework
from rest_framework.response import Response
from rest_framework import generics, status, permissions
from rest_framework.filters import OrderingFilter,SearchFilter
from rest_framework import filters
from django.utils import timezone


# Customer Management Document list 
class DocumentListApiView(generics.ListAPIView):
    serializer_class = DocumentListSerializer   
    CustomPaginationClass.page_size = 10
    filter_backends = [django_filters.rest_framework.DjangoFilterBackend, OrderingFilter,filters.SearchFilter]
    search_fields = ['customer__customer_id','customer__branch__code']

    def get_queryset(self):
        try:
            Document_list = CustomerDocumentDetails.objects.filter(is_deleted = False)
            return Document_list
        except Exception as e:
            context = {'status': False, 'message': {"error": str(e)}}
            return Response(context, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Customer Management Document Add
class AddDocument(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddDocumentSerialzier
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                # serialized_data.save()
                context={'status':True,'message':"Document added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Customer Management Document edit/delete 
class UpdateDeleteDocument(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=DocumentUpdateSerializer
    def put(self,request,id,*args,**kwargs):
        try:
            document_instance=CustomerDocumentDetails.objects.filter(id=int(id))
            serialized_data=self.serializer_class(document_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                document_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,id,*args,**kwargs):
        try:
            CustomerDocumentDetails.objects.filter(id=int(id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Document deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Customer Management Customer list 
class CustomerListApiView(generics.ListAPIView):
    serializer_class = CustomerListSerializer   
    CustomPaginationClass.page_size = 10

    filter_backends = [django_filters.rest_framework.DjangoFilterBackend, OrderingFilter,filters.SearchFilter]
    search_fields = ['customer_id','branch__code']

    def get_queryset(self):
        try:
            Customer_list = Customer.objects.filter(is_deleted = False)
            return Customer_list
        except Exception as e:
            context = {'status': False, 'message': {"error": str(e)}}
            return Response(context, status=status.HTTP_500_INTERNAL_SERVER_ERROR)