import datetime
from django.shortcuts import render
from rest_framework import status,generics,permissions
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from django.db.models import Q
from dateutil.relativedelta import relativedelta
from rest_framework.parsers import FormParser, MultiPartParser, FileUploadParser
import time
from django.utils import timezone
from .serializers import *
from api.v1.models import *
from ayaan_finserve.paginations import *
from django.core.cache import cache
from django.conf import settings
from django.core.cache.backends.base import DEFAULT_TIMEOUT
from rest_framework.permissions import (AllowAny,IsAuthenticated)
# For cache timeout
CACHE_TTL = getattr(settings, 'CACHE_TTL', DEFAULT_TIMEOUT)
from django.http import FileResponse


class PhotoSignatureView(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class = PhotoSignatureSerializer
    pagination_class = AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['customer_id']
    def get_queryset(self):
        customer_photo_signature_list = cache.get('customer_photo_signature_list')
        # print(customer_photo_signature_list,'@@@@@@@@@')
        if customer_photo_signature_list is None:
            customer_photo_signature_list = CustomerPhotoSignatureDetails.objects.filter(customer__is_active=True,customer__is_deleted=False)
            cache.set('customer_photo_signature_list', customer_photo_signature_list, timeout=CACHE_TTL)
        return customer_photo_signature_list


class PhotoSignatureEdit(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class= PhotoSignatureEditSerializer
    parser_classes = (FormParser, MultiPartParser)
    def put(self,request,customer_id,*args,**kwargs):
        try:
            customer_instance=CustomerPhotoSignatureDetails.objects.filter(customer_id=customer_id).last()
            print(request.data)
            serialized_data = self.serializer_class(customer_instance,data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                cache.delete('customer_photo_signature_list')
                context={'status':True,'message':"details updated successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    def delete(self,request,customer_id,*args,**kwargs):
        try:
            CustomerPhotoSignatureDetails.objects.filter(customer_id=customer_id).update(photo=None,signature=None)
            cache.delete('customer_photo_signature_list')
            context={'status':True,'message':"Photo and signature deleted successfully"}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PhotoSignatureUpload(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=PhotoSignatureUploadSerializer
    parser_classes = (FormParser, MultiPartParser)
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                cache.delete('customer_photo_signature_list')
                context={'status':True,'message':"details uploaded successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class CustomerRegistration(generics.GenericAPIView):
    serializer_class=CustomerRegistrationSerializer
# parser_classes = (FormParser,MultiPartParser)
    def post(self,request):
        try:
            # print(request.data)
            serialized_data = self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                context={'status':True,'message':"Customer Registered successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        



class GetCustomerStatus(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=GetCustomerStatusSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','customer__customer_id']
    def get_queryset(self):
        customer_status_list=cache.get('customer_status_list')
        if customer_status_list is None:
            customer_status_list=Customer.objects.filter(is_active=True,is_deleted=False).all()
            cache.set('customer_status_list', customer_status_list, timeout=CACHE_TTL)
        return customer_status_list


class CustomerStatusUpdate(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CustomerStatusUpdateSerializer
    def put(self,request,customer_id,*args,**kwargs):
        try:
            customer_instance=Customer.objects.filter(customer_id=customer_id).last()
            serialized_data=self.serializer_class(customer_instance,data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                customer_instance.update(updated_on=timezone.now())
                cache.delete('customer_status_list')
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class GetCustomerBankAccountDetails(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CustomerBankAccountDetailsSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','customer__customer_id']
    def get_queryset(self):
        customer_bank_account_list = cache.get('customer_bank_account_list')
        if customer_bank_account_list is None:
            customer_bank_account_list=CustomerBankAccountDetails.objects.filter(customer__is_active=True,customer__is_deleted=False)
            cache.set('customer_bank_account_list', customer_bank_account_list, timeout=CACHE_TTL)
        return customer_bank_account_list


