import datetime
from django.shortcuts import render
from rest_framework import status,generics,permissions
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import filters
import django_filters
from django.db.models import Q
from dateutil.relativedelta import relativedelta
from rest_framework.parsers import FormParser, MultiPartParser, FileUploadParser
import time
from django.utils import timezone
from .serializers import *
from api.v1.models import *
from ayaan_finserve.paginations import *


#API for Name Prefix
class NamePrefixList(generics.ListAPIView):
    permission_classes = (permissions.IsAuthenticated,)
    serializer_class=NamePrefixserialzier
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','prefix']
    def get_queryset(self):
        try:
            valid_name_prefixes = NamePrefixMaster.objects.filter(is_deleted=False).all()
            return valid_name_prefixes
        except Exception as e:
            return NamePrefixMaster.objects.none()

class UpdateNamePrefixStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=NamePrefixUpdateSerialzier
    
    def put(self,request,prefix_id,*args,**kwargs):
        try:
            prefix_instance=NamePrefixMaster.objects.filter(id=int(prefix_id))
            serialized_data=self.serializer_class(prefix_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                prefix_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
                return Response(context,status=status.HTTP_200_OK)
            else:
                context={'status':False,'message':serialized_data.errors}
                return Response(context,status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,prefix_id,*args,**kwargs):
        try:
            NamePrefixMaster.objects.filter(id=int(prefix_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Prefix deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddNamePrefix(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddNamePrefixSerialzier
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Prefix added successfully"}
                return Response(context,status=status.HTTP_200_OK)
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for Customer Type
class CustomerTypeList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CustomerTypeListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['customer_type']
    def get_queryset(self):
        try:
            valid_customer_type = CustomerTypeMaster.objects.filter(is_deleted=False).all()
            return valid_customer_type
        except Exception as e :
            return CustomerTypeMaster.objects.none()


class UpdateCustomerTypeStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CustomerTypeUpdateSerializer
    def put(self,request,customer_type_id,*args,**kwargs):
        try:
            customer_type_instance=CustomerTypeMaster.objects.filter(id=int(customer_type_id))
            serialized_data=self.serializer_class(customer_type_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                customer_type_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
                return Response(context,status=status.HTTP_200_OK)
            else:
                context={'status':False,'message':serialized_data.errors}
                return Response(context,status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,customer_type_id,*args,**kwargs):
        try:
            CustomerTypeMaster.objects.filter(id=int(customer_type_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Customer Type deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AddCustomerType(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddCustomerTypeSerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Customer Type added successfully"}
                return Response(context,status=status.HTTP_200_OK)
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for Occupation
class OccupationList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=OccupationSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','occupation']
    def get_queryset(self):
        try:
            valid_occupations = OccupationMaster.objects.filter(is_deleted=False).all()
            return valid_occupations
        except Exception as e :
            return NamePrefixMaster.objects.none()

class UpdateOccupationStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=OccupationUpdateSerialzier
    
    def put(self,request,occupation_id,*args,**kwargs):
        try:
            occupation_instance=OccupationMaster.objects.filter(id=int(occupation_id))
            serialized_data=self.serializer_class(occupation_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                occupation_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,occupation_id,*args,**kwargs):
        try:
            OccupationMaster.objects.filter(id=int(occupation_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Occupation deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddOccupation(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddOccupationSerialzier
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Occupation added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for Caste
class CasteList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CasteListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','caste']
    def get_queryset(self):
        try:
            valid_castes = CasteMaster.objects.filter(is_deleted=False).all()
            return valid_castes
        except Exception as e :
            return CasteMaster.objects.none()

class UpdateCateStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CasteUpdateSerializer
    def put(self,request,caste_id,*args,**kwargs):
        try:
            caste_instance=CasteMaster.objects.filter(id=int(caste_id))
            serialized_data=self.serializer_class(caste_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                caste_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,caste_id,*args,**kwargs):
        try:
            CasteMaster.objects.filter(id=int(caste_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Caste deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddCaste(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddCasteSerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Caste added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for relationship
class RelationshipList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=RelationshipListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','relationship']
    def get_queryset(self):
        try:
            valid_relationship = RelationshipMaster.objects.filter(is_deleted=False).all()
            return valid_relationship
        except Exception as e :
            return RelationshipMaster.objects.none()

class UpdateRelationshipStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=RelationshipUpdateSerializer
    def put(self,request,relationship_id,*args,**kwargs):
        try:
            relationship_instance=RelationshipMaster.objects.filter(id=int(relationship_id))
            serialized_data=self.serializer_class(relationship_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                relationship_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,relationship_id,*args,**kwargs):
        try:
            RelationshipMaster.objects.filter(id=int(relationship_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Relationship deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddRelationship(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddRelationshipSerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Relationship added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#API for Country
class CountryList(generics.ListAPIView):
    permission_classes=(permissions.IsAuthenticated,)
    serializer_class=CountryListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','name']
    def get_queryset(self):
        try:
            valid_countries = CountryMaster.objects.filter(is_deleted=False).all()
            return valid_countries
        except Exception as e :
            return CountryMaster.objects.none()

class UpdateCountryStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CountryUpdateSerializer
    def put(self,request,country_id,*args,**kwargs):
        try:
            country_instance=CountryMaster.objects.filter(id=int(country_id))
            serialized_data=self.serializer_class(country_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                country_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,country_id,*args,**kwargs):
        try:
            CountryMaster.objects.filter(id=int(country_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Country deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddCountry(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddCountrySerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Country added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for State
class StateList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=StateListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','name']
    def get_queryset(self):
        try:
            valid_states = StateMaster.objects.filter(is_deleted=False).all()
            return valid_states
        except Exception as e :
            return StateMaster.objects.none()

class UpdateStateStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=StateUpdateSerializer
    def put(self,request,state_id,*args,**kwargs):
        try:
            state_instance=StateMaster.objects.filter(id=int(state_id))
            serialized_data=self.serializer_class(state_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                state_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,state_id,*args,**kwargs):
        try:
            StateMaster.objects.filter(id=int(state_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'State deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddState(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddStateSerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"State added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for District
class DistrictList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=DistrictListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','name']
    def get_queryset(self):
        try:
            valid_districts = DistrictMaster.objects.filter(is_deleted=False).all()
            return valid_districts
        except Exception as e :
            return DistrictMaster.objects.none()

class UpdateDistrictStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=DistrictUpdateSerializer
    def put(self,request,district_id,*args,**kwargs):
        try:
            district_instance=DistrictMaster.objects.filter(id=int(district_id))
            serialized_data=self.serializer_class(district_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                district_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,district_id,*args,**kwargs):
        try:
            DistrictMaster.objects.filter(id=int(district_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'District deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddDistrict(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddDistrictSerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"District added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for Taluka
class TalukaList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=TalukaListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','name']
    def get_queryset(self):
        try:
            valid_taluka = TalukaMaster.objects.filter(is_deleted=False).all()
            return valid_taluka
        except Exception as e :
            return TalukaMaster.objects.none()

class UpdateTalukaStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=TalukaUpdateSerializer
    def put(self,request,taluka_id,*args,**kwargs):
        try:
            taluka_instance=TalukaMaster.objects.filter(id=int(taluka_id))
            serialized_data=self.serializer_class(taluka_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                taluka_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,taluka_id,*args,**kwargs):
        try:
            TalukaMaster.objects.filter(id=int(taluka_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Taluka deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddTaluka(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddTalukaSerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Taluka added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#API for City
class CityList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CityListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','name']
    def get_queryset(self):
        try:
            valid_city = CityMaster.objects.filter(is_deleted=False).all()
            return valid_city
        except Exception as e :
            return CityMaster.objects.none()

class UpdateCityStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=CityUpdateSerializer
    def put(self,request,city_id,*args,**kwargs):
        try:
            city_instance=CityMaster.objects.filter(id=int(city_id))
            serialized_data=self.serializer_class(city_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                city_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,city_id,*args,**kwargs):
        try:
            CityMaster.objects.filter(id=int(city_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'City deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddCity(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddCitySerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"City added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

#API for Area
class AreaList(generics.ListAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AreaListSerializer
    pagination_class=AFIDefaultPaginationClass
    filter_backends=[filters.SearchFilter]
    search_fields=['id','name']
    def get_queryset(self):
        try:
            valid_area = AreaMaster.objects.filter(is_deleted=False).all()
            return valid_area
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class UpdateAreaStatus(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AreaUpdateSerializer
    def put(self,request,area_id,*args,**kwargs):
        try:
            area_instance=AreaMaster.objects.filter(id=int(area_id))
            serialized_data=self.serializer_class(area_instance.last(),data=request.data,partial=True)
            if serialized_data.is_valid():
                serialized_data.save()
                area_instance.update(updated_on=timezone.now())
                context={'status':True,'message':'Status Updated Successfully'}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def delete(self,request,area_id,*args,**kwargs):
        try:
            AreaMaster.objects.filter(id=int(area_id)).update(is_deleted=True,updated_on=timezone.now())
            context={'status':True,'message':'Area deleted successfully'}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class AddArea(generics.GenericAPIView):
    # permission_classes=(IsAuthenticated,)
    serializer_class=AddAreaSerializer
    def post(self,request,*args,**kwargs):
        try:
            serialized_data=self.serializer_class(data=request.data)
            if serialized_data.is_valid():
                serialized_data.save()
                context={'status':True,'message':"Area added successfully"}
            else:
                context={'status':False,'message':serialized_data.errors}
            return Response(context,status=status.HTTP_200_OK)
        except Exception as e:
            context={'status':False,'message':"Something went wrong"}
            return Response(context,status=status.HTTP_500_INTERNAL_SERVER_ERROR)