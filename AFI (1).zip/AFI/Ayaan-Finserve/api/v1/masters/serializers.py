import datetime
from rest_framework import serializers
from ..models import *
from django.db import IntegrityError, transaction
from django.contrib.auth.hashers import make_password
import re

#Name prefix
class NamePrefixserialzier(serializers.ModelSerializer):
    class Meta:
        model=NamePrefixMaster
        fields=['id','prefix','is_active']

class NamePrefixUpdateSerialzier(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    prefix=serializers.CharField(max_length=20,required=True)
    class Meta:
        model=NamePrefixMaster
        fields=['is_active','prefix']

class AddNamePrefixSerialzier(serializers.ModelSerializer):
    prefix=serializers.CharField(max_length=20,required=True)
    class Meta:
        model=NamePrefixMaster
        fields=['prefix']

#Customer Type
class CustomerTypeListSerializer(serializers.ModelSerializer):
    class Meta:
        model=CustomerTypeMaster
        fields=['id','customer_type','is_active']

class CustomerTypeUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    customer_type=serializers.CharField(max_length=40,required=True)
    class Meta:
        model=CustomerTypeMaster
        fields=['customer_type','is_active']

class AddCustomerTypeSerializer(serializers.ModelSerializer):
    customer_type=serializers.CharField(max_length=40,required=True)
    class Meta:
        model=CustomerTypeMaster
        fields=['customer_type']

#Occupation
class OccupationSerializer(serializers.ModelSerializer):
    class Meta:
        model=OccupationMaster
        fields=['id','occupation','is_active']

class OccupationUpdateSerialzier(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    occupation=serializers.CharField(max_length=20,required=True)
    class Meta:
        model=OccupationMaster
        fields=['is_active','occupation']

class AddOccupationSerialzier(serializers.ModelSerializer):
    occupation=serializers.CharField(max_length=20,required=True)
    class Meta:
        model=OccupationMaster
        fields=['occupation']

#Caste
class CasteListSerializer(serializers.ModelSerializer):
    class Meta:
        model=CasteMaster
        fields=['id','caste','is_active']

class CasteUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    caste=serializers.CharField(max_length=30,required=True)
    class Meta:
        model=CasteMaster
        fields=['caste','is_active']

class AddCasteSerializer(serializers.ModelSerializer):
    caste=serializers.CharField(max_length=30,required=True)
    class Meta:
        model=CasteMaster
        fields=['caste']


#Relationship
class RelationshipListSerializer(serializers.ModelSerializer):
    class Meta:
        model=RelationshipMaster
        fields=['id','relationship','is_active']

class RelationshipUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    relationship=serializers.CharField(max_length=30,required=True)
    class Meta:
        model=CasteMaster
        fields=['relationship','is_active']

class AddRelationshipSerializer(serializers.ModelSerializer):
    relationship=serializers.CharField(max_length=30,required=True)
    class Meta:
        model=RelationshipMaster
        fields=['relationship']

#Country
class CountryListSerializer(serializers.ModelSerializer):
    class Meta:
        model=CountryMaster
        fields=['id','name','is_active']

class CountryUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    name=serializers.CharField(max_length=30,required=True)
    class Meta:
        model=CountryMaster
        fields=['name','is_active']

class AddCountrySerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=30,required=True)
    class Meta:
        model=CountryMaster
        fields=['name']

#State
class StateListSerializer(serializers.ModelSerializer):
    class Meta:
        model=StateMaster
        fields=['id','name','is_active']

class StateUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    name=serializers.CharField(max_length=30,required=True)
    country_id=serializers.IntegerField(required=True)
    class Meta:
        model=StateMaster
        fields=['name','is_active','country_id']

class AddStateSerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=30,required=True)
    country_id=serializers.IntegerField(required=True)
    class Meta:
        model=StateMaster
        fields=['name','country_id']


#District
class DistrictListSerializer(serializers.ModelSerializer):
    class Meta:
        model=DistrictMaster
        fields=['id','name','is_active']

class DistrictUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    name=serializers.CharField(max_length=30,required=True)
    state_id=serializers.IntegerField(required=True)
    class Meta:
        model=DistrictMaster
        fields=['name','is_active','state_id']

class AddDistrictSerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=30,required=True)
    state_id=serializers.IntegerField(required=True)
    class Meta:
        model=DistrictMaster
        fields=['name','state_id']

#Taluka
class TalukaListSerializer(serializers.ModelSerializer):
    class Meta:
        model=TalukaMaster
        fields=['id','name','is_active']

class TalukaUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    name=serializers.CharField(max_length=30,required=True)
    district_id=serializers.IntegerField(required=True)
    class Meta:
        model=TalukaMaster
        fields=['name','is_active','district_id']

class AddTalukaSerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=30,required=True)
    district_id=serializers.IntegerField(required=True)
    class Meta:
        model=TalukaMaster
        fields=['name','district_id']

#City
class CityListSerializer(serializers.ModelSerializer):
    class Meta:
        model=CityMaster
        fields=['id','name','is_active']

class CityUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    name=serializers.CharField(max_length=30,required=True)
    taluka_id=serializers.IntegerField(required=True)
    class Meta:
        model=CityMaster
        fields=['name','is_active','taluka_id']

class AddCitySerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=30,required=True)
    taluka_id=serializers.IntegerField(required=True)
    class Meta:
        model=CityMaster
        fields=['name','taluka_id']


#Area
class AreaListSerializer(serializers.ModelSerializer):
    class Meta:
        model=AreaMaster
        fields=['id','name','is_active']

class AreaUpdateSerializer(serializers.ModelSerializer):
    is_active=serializers.BooleanField(required=True)
    name=serializers.CharField(max_length=30,required=True)
    city_id=serializers.IntegerField(required=True)
    class Meta:
        model=AreaMaster
        fields=['name','is_active','city_id']

class AddAreaSerializer(serializers.ModelSerializer):
    name=serializers.CharField(max_length=30,required=True)
    city_id=serializers.IntegerField(required=True)
    class Meta:
        model=AreaMaster
        fields=['name','city_id']