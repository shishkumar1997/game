# Ayaan-Finserve
python 3.6
python manage.py runserver 0.0.0.0:8000
